# Example for extracting parts and documents from a ZIP file
This example assumes that the ZIP file contains a directory structure like:
- Part1 Test Part/
  - Document 1.doc
  - more_files/
    - stepfile.step
    - Document.doc
- Part101-Example Part/
  - Document 3.doc
  - stepfile.step
- Part3030 New Part/
  - Document 4.doc

The resulting parts format after running batch process parts:

```JSON
{
    "parts": [
        {
            "displayName": "Test Part",
            "partPrefix": "Part",
            "name": "Part1 Test Part",
            "partNumber": "1",
            "partFiles": [
                {
                    "fileName": "Part1 Test Part/more_files/stepfile.step",
                    "displayName": "stepfile.step"
                }
            ]
        }
    ]
}
```

The resulting documents format after running batch process part:
```JSON
```